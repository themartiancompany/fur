===============
Android Display Utils Authors
===============

* Pellegrino Prevete <pellegrinoprevete@gmail.com>
* Truocolo <truocolo@aol.com>
