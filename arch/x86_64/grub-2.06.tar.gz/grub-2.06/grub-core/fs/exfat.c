#define MODE_EXFAT 1
#include "fat.c"
